/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 16:51:18 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 16:51:33 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_H
# define PIPEX_H

# include "libft.h" // Include the custom library header (libft.h)
# include <stdio.h> // Include the standard input/output library header (stdio.h)
# include <sys/types.h> // Include the types library header (sys/types.h)
# include <sys/wait.h> // Include the wait library header (sys/wait.h)
# include <sys/stat.h> // Include the stat library header (sys/stat.h)

# define ERR_NOTENOUGHARGS "pipex: not enough arguments.\n" // Define an error message for not enough arguments
# define ERR_PATHNOTFOUND "pipex: could not find PATH.\n" // Define an error message for PATH not found
# define ERR_ALLOC "pipex: could not allocate memory.\n" // Define an error message for memory allocation failure

// Define a structure named t_env to hold environment-related information
typedef struct s_env
{
	char	**path; // Array of strings representing the PATH variable
	char	**envp; // Array of strings representing the environment variables
}			t_env;

// first_part.c
int		first_part(int fd[2], int pipefd[2], char *arg, t_env *env); // Function prototype for the first part of the pipex command
int		here_doc_first_part(int fd[2], int pipefd[2], char *arg, t_env *env); // Function prototype for the first part of the here_doc pipex command

// middle_part.c
int		middle_part(int fd[2], int pipefd[2], char *arg, t_env *env); // Function prototype for the middle part of the pipex command

// last_part.c
int		last_part(int fd[2], int pipefd[2], char *arg, t_env *env); // Function prototype for the last part of the pipex command

// get_path.c
char	**get_path(char *envp[]); // Function prototype to extract and return the PATH variable as an array of strings

// open_files.c
int		open_infile(const char *filename); // Function prototype to open an input file and return the file descriptor
int		open_outfile(const char *filename); // Function prototype to open an output file and return the file descriptor
int		here_doc_open_outfile(const char *filename); // Function prototype to open an output file for here_doc and return the file descriptor

// execute_cmd.c
int		execute_cmd(char *cmd, t_env *env); // Function prototype to execute a command

// end_pipex.c
void	end_pipex(int fd[2], char **path); // Function prototype to close file descriptors and free memory at the end of pipex

// utils.c
void	print_file(int fd); // Function prototype to print the contents of a file
void	print_path(char **path); // Function prototype to print the PATH variable

#endif // End of the include guard
