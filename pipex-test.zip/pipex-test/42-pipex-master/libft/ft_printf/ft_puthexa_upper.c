/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_puthexa_upper.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:02:05 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:02:09 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to print the hexadecimal representation of an unsigned integer in uppercase.
size_t ft_puthexa_upper(const unsigned int n)
{
    if (n / 16) // If there are more hexadecimal digits.
        return (ft_puthexa_upper(n / 16) + ft_puthexa_upper(n % 16)); // Recursively print each hexadecimal digit.
    else if (!(n / 10)) // If the digit is less than 10.
        ft_putchar(n + '0'); // Print the digit.
    else // If the digit is greater than or equal to 10.
        ft_putchar((char) n - 10 + 'A'); // Print the corresponding uppercase hexadecimal character.
    return (1); // Return the size of the printed character.
}
