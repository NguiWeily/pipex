/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:02:30 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:02:36 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to recursively print each digit of a number.
static size_t print_nb(long nb)
{
    if (nb / 10) // If there are more digits in the number.
        return (print_nb(nb / 10) + print_nb(nb % 10)); // Recursively print each digit.
    else // If it's the last digit.
        return (ft_putchar(nb + '0')); // Print the digit as a character.
}

// Function to print a signed integer.
size_t ft_putnbr(const int n)
{
    long nb; // Variable to hold the number.

    nb = n; // Assign the value of 'n' to 'nb'.
    if (nb < 0) // If the number is negative.
    {
        nb = -nb; // Make it positive.
        return (ft_putchar('-') + print_nb(nb)); // Print '-' sign and the positive number.
    }
    else // If the number is positive.
        return (print_nb(nb)); // Print the positive number.
}
