/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:00:19 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:00:27 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to handle conversion specifier and print corresponding formatted output.
static size_t conversion(const char *c, size_t *i, va_list *ap)
{
    *i = *i + 1; // Move to the next character in the format string.
    if (*(c + 1) == 'c') // If the conversion specifier is for a character.
        return (ft_putchar((char) va_arg(*ap, int))); // Print character argument.
    else if (*(c + 1) == 's') // If the conversion specifier is for a string.
        return (ft_putstr(va_arg(*ap, const char *))); // Print string argument.
    else if (*(c + 1) == 'p') // If the conversion specifier is for a pointer address.
        return (ft_putadress(va_arg(*ap, void *))); // Print pointer address argument.
    else if (*(c + 1) == 'd' || *(c + 1) == 'i') // If the conversion specifier is for a decimal integer.
        return (ft_putnbr(va_arg(*ap, int))); // Print decimal integer argument.
    else if (*(c + 1) == 'u') // If the conversion specifier is for an unsigned decimal integer.
        return (ft_putunbr(va_arg(*ap, unsigned int))); // Print unsigned decimal integer argument.
    else if (*(c + 1) == 'x') // If the conversion specifier is for a lowercase hexadecimal integer.
        return (ft_puthexa_lower(va_arg(*ap, int))); // Print lowercase hexadecimal integer argument.
    else if (*(c + 1) == 'X') // If the conversion specifier is for an uppercase hexadecimal integer.
        return (ft_puthexa_upper(va_arg(*ap, int))); // Print uppercase hexadecimal integer argument.
    else if (*(c + 1) == '%') // If the conversion specifier is for the percent sign.
        return (ft_putchar('%')); // Print percent sign.
    else if (*(c + 1) && *(c + 2)) // If there are characters after '%'.
        return (ft_putchar(*(c)) + ft_putchar(*(c + 1))); // Print the characters.
    else // If invalid conversion specifier.
    {
        *i -= 1; // Decrement the index to keep it at the current position.
        return (-1); // Return error code.
    }
}

// Main function to print formatted output.
int ft_printf(const char *str, ...)
{
    int len; // Length of the formatted output.
    int tmp; // Temporary storage for result of conversion.
    va_list ap; // Variable arguments list.
    size_t i; // Index for iterating through the format string.

    if (!str) // If the input string is NULL.
        return (-1); // Return error code.
    len = 0; // Initialize length of formatted output.
    va_start(ap, str); // Initialize variable arguments list.
    i = 0; // Initialize index for iterating through the format string.
    while (str[i]) // Iterate through the format string until null terminator.
    {
        if (str[i] == '%') // If '%' character is encountered.
            tmp = conversion(str + i, &i, &ap); // Process conversion specifier and get formatted output.
        else // If regular character.
            tmp = ft_putchar(str[i]); // Print the character directly.
        if (tmp >= 0) // If conversion successful.
            len += tmp; // Increment length by the size of the formatted output.
        else // If conversion failed.
            len = tmp; // Assign error code to length.
        i++; // Move to the next character in the format string.
    }
    va_end(ap); // End variable arguments list.
    return (len); // Return the length of the formatted output.
}
