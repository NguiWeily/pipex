/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putadress.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:00:44 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:00:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to print the hexadecimal representation of a memory address.
static size_t printadress(const unsigned long n)
{
    if (n / 16) // If there are more digits in the address.
        return (printadress(n / 16) + printadress(n % 16)); // Recursively print each digit.
    else if (!(n / 10)) // If the digit is less than 10.
        ft_putchar(n + '0'); // Print the digit.
    else // If the digit is greater than or equal to 10.
        ft_putchar((char) n - 10 + 'a'); // Print the corresponding hexadecimal character.
    return (1); // Return the size of the printed character.
}

// Function to print a memory address in hexadecimal format.
size_t ft_putadress(void *adress)
{
    if (!adress) // If the address is NULL.
        return (ft_putstr("(nil)")); // Print "(nil)" and return its length.
    ft_putstr("0x"); // Print "0x" to indicate a hexadecimal address.
    return (2 + printadress((unsigned long) adress)); // Return the length of "0x" plus the printed address.
}
