/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_puthexa_lower.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:01:37 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:01:40 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to print the hexadecimal representation of an unsigned integer in lowercase.
size_t ft_puthexa_lower(const unsigned int n)
{
    if (n / 16) // If there are more hexadecimal digits.
        return (ft_puthexa_lower(n / 16) + ft_puthexa_lower(n % 16)); // Recursively print each hexadecimal digit.
    else if (!(n / 10)) // If the digit is less than 10.
        ft_putchar(n + '0'); // Print the digit.
    else // If the digit is greater than or equal to 10.
        ft_putchar((char) n - 10 + 'a'); // Print the corresponding lowercase hexadecimal character.
    return (1); // Return the size of the printed character.
}
