/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:18:37 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:18:40 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

int ft_lstsize(t_list *lst) // Define a function named ft_lstsize that takes a pointer to a t_list (lst) as an argument and returns the number of elements in the list.
{
	int size; // Declare a variable to store the size of the list.

	size = 0; // Initialize the size variable to 0.
	while (lst) // Iterate through the list until lst is NULL.
	{
		size++; // Increment the size for each node in the list.
		lst = lst->next; // Move to the next node in the list.
	}
	return (size); // Return the total size of the list.
}
