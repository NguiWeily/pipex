/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:23:01 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:23:03 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_striteri that applies the function f to each character of the string s, along with its index.
void ft_striteri(char *s, void (*f)(unsigned int, char *))
{
	size_t i; // Declare a variable to iterate through the characters of the string.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i]) // Iterate through the characters of the string until reaching the null terminator.
	{
		(*f)(i, s + i); // Call the function f with the index i and the address of the current character in the string.
		i++; // Increment the iterator to move to the next character in the string.
	}
}
