/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:26:15 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:26:17 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strlcat that appends the string s to the end of the string d with a specified maximum size dstsize.
size_t ft_strlcat(char *d, const char *s, size_t dstsize)
{
	size_t dst_len; // Declare a variable to store the length of the destination string d.
	size_t index; // Declare a variable to track the current position in the destination string d.
	size_t i; // Declare a variable to iterate through the characters of the source string s.

	dst_len = ft_strlen(d); // Get the length of the destination string d.
	index = 0; // Initialize the index variable to 0.
	while (d[index]) // Iterate through the characters of the destination string until reaching the null terminator.
		index++; // Increment the index to move to the next character in the destination string.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i] && (i + index + 1) < (dstsize)) // Iterate through the characters of the source string until reaching the null terminator or reaching the maximum size.
	{
		d[index + i] = s[i]; // Append each character from the source string s to the destination string d.
		i++; // Increment the iterator to move to the next character in the source string.
	}

	if (i < dstsize) // Check if there is space for a null terminator in the destination string.
		d[index + i] = '\0'; // Add a null terminator at the end of the concatenated string.

	if (dstsize <= dst_len) // Check if the maximum size is less than or equal to the length of the destination string.
		return (ft_strlen(s) + dstsize); // If so, return the sum of the length of the source string and the maximum size.
	else // If the maximum size is greater than the length of the destination string,
		return (ft_strlen(s) + dst_len); // return the sum of the length of the source string and the length of the destination string.
}
