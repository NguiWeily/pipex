/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:21:09 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:21:12 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strdup that duplicates the string s1.
char *ft_strdup(const char *s1)
{
	char *new; // Declare a pointer to store the duplicated string.
	size_t i; // Declare a variable to iterate through the characters of the string.

	new = malloc(sizeof(char) * (ft_strlen(s1) + 1)); // Allocate memory for the duplicated string, including space for the null terminator.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	i = 0; // Initialize the iterator variable to 0.
	while (s1[i]) // Iterate through the characters of the original string until reaching the null terminator.
	{
		new[i] = s1[i]; // Copy each character from the original string to the duplicated string.
		i++; // Increment the iterator to move to the next character in the original string.
	}
	new[i] = '\0'; // Add a null terminator at the end of the duplicated string.
	return (new); // Return a pointer to the duplicated string.
}
