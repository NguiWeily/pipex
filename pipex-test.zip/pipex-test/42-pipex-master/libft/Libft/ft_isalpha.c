/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:13:57 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:14:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Including the header file that contains function prototypes and structure definitions.

int	ft_isalpha(int c) // Function to check if a character is alphabetic.
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) // Checking if the character is within the range of lowercase or uppercase alphabets.
		return (1); // Returning 1 if the character is alphabetic.
	return (0); // Returning 0 if the character is not alphabetic.
}
