/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_front_bonus.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:25:33 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:25:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_lstadd_front(t_list **alst, t_list *new) // Define a function named ft_lstadd_front that takes a pointer to a pointer to a t_list (alst) and a pointer to a t_list (new) as arguments.
{
	if (!alst || !new) // Check if either alst or new is NULL.
		return; // If either alst or new is NULL, exit the function.

	new->next = *alst; // Set the next pointer of the new node to point to the current head of the list.
	*alst = new; // Update the head pointer to point to the new node, making it the new head of the list.
}
