/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:15:49 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:15:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strnstr that finds the first occurrence of the string needle in the string haystack within a specified length len.
char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t len_n; // Declare a variable to store the length of the needle string.
	size_t i; // Declare a variable to iterate through the characters of the haystack string.
	size_t j; // Declare a variable to iterate through the characters of the needle string.

	if (!haystack || !needle) // Check if either the haystack or the needle string is NULL.
		return (NULL); // If either the haystack or the needle string is NULL, return NULL.

	if (ft_strlen(needle) == 0) // Check if the length of the needle string is 0.
		return ((char *) haystack); // If the length of the needle string is 0, return a pointer to the beginning of the haystack string.

	len_n = ft_strlen(needle); // Get the length of the needle string.
	i = 0; // Initialize the iterator variable i to 0.
	while (haystack[i] && i < len) // Iterate through the characters of the haystack string until reaching the null terminator or the specified length len.
	{
		j = 0; // Initialize the iterator variable j to 0.
		while (haystack[i + j] && haystack[i + j] == needle[j] && i + j < len) // Iterate through the characters of the haystack and needle strings until reaching the null terminator, encountering different characters, or reaching the specified length len.
			j++; // Increment the iterator to move to the next character in the strings.

		if (j == len_n) // Check if the entire needle string is found in the haystack string.
			return ((char *) haystack + i); // If so, return a pointer to the beginning of the occurrence of the needle string in the haystack string.

		i++; // Increment the iterator to move to the next character in the haystack string.
	}
	return (NULL); // If the needle string is not found in the haystack string within the specified length, return NULL.
}
