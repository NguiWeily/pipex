/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:24:10 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:24:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void *ft_memcpy(void *dst, const void *src, size_t n) // Define a function named ft_memcpy that copies n bytes from the memory area pointed to by src to the memory area pointed to by dst.
{
	size_t i; // Declare a variable to iterate through the memory areas.

	i = 0; // Initialize the iterator variable to 0.
	while (i < n) // Iterate through the memory areas until i reaches n.
	{
		*(unsigned char *)(dst + i) = *(unsigned char *)(src + i); // Copy the byte at the current position from src to the corresponding position in dst.
		i++; // Increment the iterator to move to the next byte in the memory areas.
	}
	return (dst); // Return a pointer to the destination memory area.
}
