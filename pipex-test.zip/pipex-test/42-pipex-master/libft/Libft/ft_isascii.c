/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:16:16 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:16:18 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

int ft_isascii(int c) // Define a function named ft_isascii that takes an integer argument c.
{
	if (c >= 0 && c <= 127) // Check if the integer c falls within the ASCII range (0 to 127).
		return (1); // If c is an ASCII character, return 1 to indicate true.
	return (0); // If c is not an ASCII character, return 0 to indicate false.
}
