/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:08:45 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:08:49 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_putchar_fd(char c, int fd) // Define a function named ft_putchar_fd that writes a character c to the file descriptor fd.
{
	write(fd, &c, 1); // Write the character c to the file descriptor fd, reading 1 byte from the address of c.
}
