/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdelone_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:08:22 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:08:25 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_lstdelone(t_list *lst, void (*del)(void *)) // Define a function named ft_lstdelone that takes a pointer to a t_list (lst) and a function pointer del as arguments.
{
	if (!lst) // Check if lst is NULL.
		return; // If lst is NULL, exit the function.

	if (del) // Check if del is not NULL.
		del(lst->content); // Call the del function pointer on the content of the node to free any allocated memory associated with it.

	free(lst); // Free the memory allocated for the node itself.
}
