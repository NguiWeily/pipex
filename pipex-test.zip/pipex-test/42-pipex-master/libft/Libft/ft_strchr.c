/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:19:00 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:19:03 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

##include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strchr that searches for the first occurrence of the character c in the string s.
char *ft_strchr(const char *s, int c)
{
	size_t i; // Declare a variable to iterate through the characters of the string.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i]) // Iterate through the characters of the string until reaching the null terminator.
	{
		if (s[i] == (char) c) // Check if the current character matches the specified character c.
			break; // If a match is found, exit the loop.
		i++; // Increment the iterator to move to the next character in the string.
	}
	if (s[i] == (char) c) // Check if a match is found.
		return ((char *) s + i); // If a match is found, return a pointer to the location of the character in the string.
	return (NULL); // If no match is found, return NULL.
}

// Define a function named ft_countc that counts the occurrences of the character c in the string str.
size_t ft_countc(const char *str, char c)
{
	size_t count; // Declare a variable to store the count of occurrences.
	size_t i; // Declare a variable to iterate through the characters of the string.

	if (!str) // Check if the string pointer is NULL.
		return (0); // If the string pointer is NULL, return 0.

	count = 0; // Initialize the count variable to 0.
	i = 0; // Initialize the iterator variable to 0.
	while (str[i]) // Iterate through the characters of the string until reaching the null terminator.
	{
		if (str[i] == c) // Check if the current character matches the specified character c.
			count++; // If a match is found, increment the count variable.
		i++; // Increment the iterator to move to the next character in the string.
	}
	return (count); // Return the total count of occurrences of the character c in the string.
}
