/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:11:56 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:11:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Including the header file that contains function prototypes and structure definitions.

int	ft_isalnum(int c) // Function to check if a character is alphanumeric.
{
	if (ft_isalpha(c) || ft_isdigit(c)) // Checking if the character is alphabetic or numeric.
		return (1); // Returning 1 if the character is alphanumeric.
	else
		return (0); // Returning 0 if the character is not alphanumeric.
}
