/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:25:57 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:26:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void *ft_memmove(void *dst, const void *src, size_t len) // Define a function named ft_memmove that copies len bytes from the memory area pointed to by src to the memory area pointed to by dst, even if the memory areas overlap.
{
	long i; // Declare a variable to iterate through the memory areas.

	if (dst < src) // If dst is located before src in memory (no overlap),
	{
		i = 0; // Initialize the iterator variable to 0.
		while ((size_t)i < len) // Iterate through the memory areas until i reaches len.
		{
			*(unsigned char *)(dst + i) = *(unsigned char *)(src + i); // Copy the byte at the current position from src to the corresponding position in dst.
			i++; // Increment the iterator to move to the next byte in the memory areas.
		}
		return (dst); // Return a pointer to the destination memory area.
	}
	else // If dst is located after src in memory (overlap),
	{
		i = len - 1; // Initialize the iterator variable to len - 1.
		while (i >= 0) // Iterate through the memory areas in reverse order until i becomes negative.
		{
			*(unsigned char *)(dst + i) = *(unsigned char *)(src + i); // Copy the byte at the current position from src to the corresponding position in dst.
			i--; // Decrement the iterator to move to the previous byte in the memory areas.
		}
		return (dst); // Return a pointer to the destination memory area.
	}
}
