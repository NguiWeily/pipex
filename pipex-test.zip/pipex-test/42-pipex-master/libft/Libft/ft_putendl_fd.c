/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putendl_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:11:00 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:11:02 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_putendl_fd(char const *s, int fd) // Define a function named ft_putendl_fd that writes the string s followed by a newline character to the file descriptor fd.
{
	size_t i; // Declare a variable to iterate through the characters of the string.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i]) // Iterate through the characters of the string until reaching the null terminator.
		i++; // Increment the iterator to move to the next character in the string.

	write(fd, s, i); // Write the characters of the string s to the file descriptor fd, reading i bytes from the address of s.
	write(fd, "\n", 1); // Write a newline character to the file descriptor fd.
}
