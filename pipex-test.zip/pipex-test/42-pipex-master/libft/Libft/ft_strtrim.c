/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:19:44 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:19:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a static function named find_begin that finds the beginning of the trimmed string by skipping leading characters from the set.
static char *find_begin(char const *s1, char const *set)
{
	size_t i; // Declare a variable to iterate through the characters of the string s1.
	size_t j; // Declare a variable to iterate through the characters of the set.
	int in_set; // Declare a variable to track if a character is found in the set.

	in_set = 0; // Initialize the variable in_set to 0.
	i = 0; // Initialize the iterator variable i to 0.
	j = 0; // Initialize the iterator variable j to 0.
	while (s1[i]) // Iterate through the characters of the string s1 until reaching the null terminator.
	{
		in_set = 0; // Reset the variable in_set to 0 for each character of s1.
		j = 0; // Reset the iterator variable j to 0 for each character of s1.
		while (set[j]) // Iterate through the characters of the set until reaching the null terminator.
		{
			if (s1[i] == set[j]) // Check if the current character of s1 is in the set.
				in_set = 1; // If the character is found in the set, set in_set to 1.
			j++; // Increment the iterator to move to the next character in the set.
		}
		if (!in_set) // Check if the current character of s1 is not in the set.
			break; // If the character is not in the set, break out of the loop.
		i++; // Increment the iterator to move to the next character in the string s1.
	}
	return ((char *)s1 + i); // Return a pointer to the beginning of the trimmed string.
}

// Define a static function named find_end that finds the end of the trimmed string by skipping trailing characters from the set.
static char *find_end(char const *s1, char const *set, char const *begin)
{
	size_t i; // Declare a variable to iterate through the characters of the string s1.
	size_t j; // Declare a variable to iterate through the characters of the set.
	int in_set; // Declare a variable to track if a character is found in the set.

	in_set = 0; // Initialize the variable in_set to 0.
	i = ft_strlen(s1) - 1; // Initialize the iterator variable i to the index of the last character of the string s1.
	j = 0; // Initialize the iterator variable j to 0.
	while (s1 + i >= begin) // Iterate through the characters of the string s1 from the end to the beginning until reaching the beginning of the trimmed string.
	{
		in_set = 0; // Reset the variable in_set to 0 for each character of s1.
		j = 0; // Reset the iterator variable j to 0 for each character of s1.
		while (set[j]) // Iterate through the characters of the set until reaching the null terminator.
		{
			if (s1[i] == set[j]) // Check if the current character of s1 is in the set.
				in_set = 1; // If the character is found in the set, set in_set to 1.
			j++; // Increment the iterator to move to the next character in the set.
		}
		if (!in_set) // Check if the current character of s1 is not in the set.
			break; // If the character is not in the set, break out of the loop.
		i--; // Decrement the iterator to move to the previous character in the string s1.
	}
	if (s1 + i < begin) // Check if the trimmed string is empty.
		return ((char *)begin); // If the trimmed string is empty, return a pointer to the beginning of the trimmed string.
	return ((char *)s1 + i); // Return a pointer to the end of the trimmed string.
}

// Define a static function named fill_str that creates a new string by copying characters from the beginning to the end of the trimmed string.
static char *fill_str(char const *begin, char const *end)
{
	char *new; // Declare a pointer to store the new string.
	size_t i; // Declare a variable to iterate through the characters of the trimmed string.

	new = malloc(sizeof(char) * (end - begin + 2)); // Allocate memory for the new string, including space for the null terminator.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	i = 0; // Initialize the iterator variable i to 0.
	while (begin + i <= end) // Iterate through the characters of the trimmed string until reaching the end.
	{
		new[i] = begin[i]; // Copy each character from the trimmed string to the new string.
		i++; // Increment the iterator to move to the next character.
	}
	new[i] = '\0'; // Add the null terminator to the end of the new string.
	return (new); // Return a pointer to the new string.
}

// Define a function named ft_strtrim that trims leading and trailing characters from the set from the string s1.
char *ft_strtrim(char const *s1, char const *set)
{
	char *begin; // Declare a pointer to store the beginning of the trimmed string.
	char *end; // Declare a pointer to store the end of the trimmed string.
	char *new; // Declare a pointer to store the new trimmed string.

	begin = find_begin(s1, set); // Find the beginning of the trimmed string by skipping leading characters from the set.
	end = find_end(s1, set, s1); // Find the end of the trimmed string by skipping trailing characters from the set.
	if (!s1[0] || end < begin) // Check if the string s1 is empty or the end is before the beginning.
	{
		new = malloc(sizeof(char) * 1); // Allocate memory for an empty string.
		if (!new) // Check if memory allocation failed.
			return (NULL); // If memory allocation failed, return NULL.
		new[0] = '\0'; // Set the null terminator for the empty string.
	}
	else // If the string s1 is not empty and there are characters to trim.
		new = fill_str(begin, end); // Create a new trimmed string by copying characters from the beginning to the end of the trimmed string.

	if (!new) // Check if memory allocation failed for the new trimmed string.
		return (NULL); // If memory allocation failed, return NULL.
	return (new); // Return a pointer to the new trimmed string.
}
