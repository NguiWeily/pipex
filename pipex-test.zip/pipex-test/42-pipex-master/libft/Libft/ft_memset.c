/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:07:28 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:07:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void *ft_memset(void *b, int c, size_t len) // Define a function named ft_memset that fills the first len bytes of the memory area pointed to by b with the constant byte c.
{
	size_t i; // Declare a variable to iterate through the memory area.

	if (!b) // Check if b is NULL.
		return (NULL); // If b is NULL, return NULL.

	i = 0; // Initialize the iterator variable to 0.
	while (i < len) // Iterate through the memory area until i reaches len.
	{
		*(unsigned char *)(b + i) = (unsigned char) c; // Set the byte at the current position in the memory area to the value of c.
		i++; // Increment the iterator to move to the next byte in the memory area.
	}
	return (b); // Return a pointer to the updated memory area.
}
