/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:24:38 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:24:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a static function named ft_strrjoin_bis that concatenates the string s3 to the end of the string new.
static void ft_strrjoin_bis(char *new, char const *s3)
{
	size_t i; // Declare a variable to iterate through the characters of the string.

	i = 0; // Initialize the iterator variable to 0.
	while (s3[i]) // Iterate through the characters of the string s3 until reaching the null terminator.
	{
		new[i] = s3[i]; // Copy each character from s3 to the end of new.
		i++; // Increment the iterator to move to the next character in the string.
	}
	new[i] = '\0'; // Add a null terminator at the end of the concatenated string.
}

// Define a function named ft_strrjoin that concatenates three strings: s1, s2, and s3.
char *ft_strrjoin(char const *s1, char const *s2, char const *s3)
{
	char *new; // Declare a pointer to store the concatenated string.
	size_t i; // Declare a variable to iterate through the characters of s1.
	size_t j; // Declare a variable to iterate through the characters of s2.

	if (!s1 || !s2 || !s3) // Check if any of the input strings are NULL.
		return (NULL); // If any of the input strings are NULL, return NULL.

	new = malloc(sizeof(char) * (ft_strlen(s1) + ft_strlen(s2) + ft_strlen(s3) + 1)); // Allocate memory for the concatenated string, including space for the null terminator.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	i = 0; // Initialize the iterator variable i to 0.
	while (s1[i]) // Iterate through the characters of s1 until reaching the null terminator.
	{
		new[i] = s1[i]; // Copy each character from s1 to the concatenated string new.
		i++; // Increment the iterator to move to the next character in s1.
	}

	j = 0; // Initialize the iterator variable j to 0.
	while (s2[j]) // Iterate through the characters of s2 until reaching the null terminator.
	{
		new[i + j] = s2[j]; // Copy each character from s2 to the concatenated string new starting from the position after s1.
		j++; // Increment the iterator to move to the next character in s2.
	}

	ft_strrjoin_bis(new + i + j, s3); // Concatenate the string s3 to the end of the concatenated string new.
	return (new); // Return a pointer to the concatenated string.
}

// Define a function named ft_strjoin that concatenates two strings: s1 and s2.
char *ft_strjoin(char const *s1, char const *s2)
{
	char *new; // Declare a pointer to store the concatenated string.
	size_t i; // Declare a variable to iterate through the characters of s1.
	size_t j; // Declare a variable to iterate through the characters of s2.

	new = malloc(sizeof(char) * (ft_strlen(s1) + ft_strlen(s2) + 1)); // Allocate memory for the concatenated string, including space for the null terminator.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	i = 0; // Initialize the iterator variable i to 0.
	while (s1[i]) // Iterate through the characters of s1 until reaching the null terminator.
	{
		new[i] = s1[i]; // Copy each character from s1 to the concatenated string new.
		i++; // Increment the iterator to move to the next character in s1.
	}

	j = 0; // Initialize the iterator variable j to 0.
	while (s2[j]) // Iterate through the characters of s2 until reaching the null terminator.
	{
		new[i + j] = s2[j]; // Copy each character from s2 to the concatenated string new starting from the position after s1.
		j++; // Increment the iterator to move to the next character in s2.
	}

	new[i + j] = '\0'; // Add a null terminator at the end of the concatenated string.
	return (new); // Return a pointer to the concatenated string.
}
