/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:18:13 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:18:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

int ft_isdigit(int c) // Define a function named ft_isdigit that takes an integer argument c.
{
	if (c >= '0' && c <= '9') // Check if the integer c represents a digit character (0-9) in the ASCII table.
		return (1); // If c is a digit character, return 1 to indicate true.
	return (0); // If c is not a digit character, return 0 to indicate false.
}
