/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:13:19 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:13:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strncmp that compares the first n characters of the strings s1 and s2.
int ft_strncmp(const char *s1, const char *s2, size_t n)
{
	size_t i; // Declare a variable to iterate through the characters of the strings.

	i = 0; // Initialize the iterator variable to 0.
	while (s1[i] && s1[i] == s2[i] && i < n) // Iterate through the characters of the strings until reaching the null terminator of s1, encountering different characters, or reaching the specified limit n.
		i++; // Increment the iterator to move to the next character in the strings.
	if (i < n) // Check if the comparison reached the specified limit n.
		return ((unsigned char) s1[i] - (unsigned char) s2[i]); // If so, return the difference between the characters at position i in the strings.
	return (0); // If the comparison reached the end of the specified limit without encountering any differences, return 0.
}

// Define a function named ft_strcmp that compares the strings s1 and s2.
int ft_strcmp(const char *s1, const char *s2)
{
	size_t i; // Declare a variable to iterate through the characters of the strings.

	i = 0; // Initialize the iterator variable to 0.
	while (s1[i] && s1[i] == s2[i]) // Iterate through the characters of the strings until reaching the null terminator of s1 or encountering different characters.
		i++; // Increment the iterator to move to the next character in the strings.
	return ((unsigned char) s1[i] - (unsigned char) s2[i]); // Return the difference between the characters at position i in the strings.
}
