/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:09:13 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:09:16 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strlen that calculates the length of the string s.
size_t ft_strlen(const char *s)
{
	size_t i; // Declare a variable to iterate through the characters of the string.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i]) // Iterate through the characters of the string until reaching the null terminator.
		i++; // Increment the iterator to move to the next character in the string.
	return (i); // Return the total number of characters counted.
}
