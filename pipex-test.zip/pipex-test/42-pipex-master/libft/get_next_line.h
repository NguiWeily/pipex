/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:06:13 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:06:17 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

##ifndef GET_NEXT_LINE_H // Header guard to prevent multiple inclusion of the header file.
# define GET_NEXT_LINE_H // Define the header file if not defined already.

# ifndef BUFFER_SIZE // Checking if BUFFER_SIZE macro is not defined.
#  define BUFFER_SIZE 42 // Defining BUFFER_SIZE macro with a default value of 42.
# endif

# include "libft.h" // Including the header file for the library functions.

# include <stdlib.h> // Including the header file for standard library functions.
# include <unistd.h> // Including the header file for standard I/O functions.
# include <fcntl.h> // Including the header file for file control functions.
# include <stdio.h> // Including the header file for standard I/O functions.

typedef struct s_bufferList // Defining a structure for buffer node.
{
	char				*content; // Pointer to content of buffer.
	struct s_bufferList	*next; // Pointer to next buffer node.
}						t_bufferList; // Typedefining the structure as t_bufferList.

typedef struct s_fdList // Defining a structure for file descriptor node.
{
	int					fd; // File descriptor.
	t_bufferList		*begin; // Pointer to the beginning of buffer list.
	struct s_fdList		*next_fd; // Pointer to next file descriptor node.
}					t_fdList; // Typedefining the structure as t_fdList.

/* Declaration of functions in get_next_line.c */
char			*get_next_line(int fd); // Function to read a line from a file descriptor.

/* Declaration of utility functions in get_next_line_utils.c */
t_bufferList	*ftlst_new_buffer(void); // Function to create a new buffer node.
t_fdList		*ftlst_new_fd(int fd); // Function to create a new file descriptor node.
int				end_of_line(char *content); // Function to check if end of line is reached in buffer content.
size_t			count_memory(t_bufferList *current); // Function to count the total memory required to store content of all buffer nodes.
t_fdList		*clean_fd_list(t_fdList *fd_list, t_fdList *current); // Function to clean up file descriptor list.

#endif // End of header guard.
