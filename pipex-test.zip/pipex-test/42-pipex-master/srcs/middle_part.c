/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   middle_part.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:29:27 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:29:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to handle the case when the process ID is 0 in the middle part
static void	middle_part_pid_0(int new_pipefd[2], int pipefd[2], \
	char *arg, t_env *env)
{
    // Close the unused ends of the pipes
	close(new_pipefd[0]);
    
    // Redirect stdin to the input end of the previous pipe
	dup2(pipefd[0], STDIN_FILENO);
    
    // Redirect stdout to the output end of the current pipe
	dup2(new_pipefd[1], STDOUT_FILENO);
    
    // Execute the command using execute_cmd function
	execute_cmd(arg, env);
    
    // Close the input end of the previous pipe and the output end of the current pipe
	close(pipefd[0]);
	close(new_pipefd[1]);
}

// Function to handle the middle part of the pipex command
int	middle_part(int fd[2], int pipefd[2], char *arg, t_env *env)
{
	int	pid;
	int	new_pipefd[2];

    // Close the output end of the previous pipe
	close(pipefd[1]);
    
    // Create a new pipe for communication between the processes
	if (pipe(new_pipefd) == -1)
		return (perror("pipex: pipe"), end_pipex(fd, env->path), 0);
    
    // Create a child process
	pid = fork();
    
    // Check if fork failed
	if (pid == -1)
		return (perror("pipex: fork"), \
		close(pipefd[0]), close(pipefd[1]), end_pipex(fd, env->path), 0);
	else if (pid == 0)
	{
        // In the child process, call the middle_part_pid_0 function
		middle_part_pid_0(new_pipefd, pipefd, arg, env);
        
        // Cleanup resources and exit the child process
		end_pipex(fd, env->path);
		exit(1);
	}
	else
	{
        // In the parent process, update the input and output ends of the pipe
		pipefd[0] = new_pipefd[0];
		pipefd[1] = new_pipefd[1];
	}
    
    // Return success
	return (1);
}
