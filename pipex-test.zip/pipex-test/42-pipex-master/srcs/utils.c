/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:30:30 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:30:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to print the contents of a file descriptor to standard error
void	print_file(int fd)
{
	char	*line;

    // Infinite loop to read lines from the file descriptor
	while (1)
	{
        // Get the next line from the file descriptor
		line = get_next_line(fd);
        // Break if there are no more lines to read
		if (!line)
			break ;
        // Print the line to standard error
		ft_putstr_fd(line, 2);
        // Free the allocated memory for the line
		free(line);
	}
}

// Function to print the contents of an array of strings
void	print_path(char **path)
{
	size_t	i;

    // Return if the path array is NULL
	if (!path)
		return ;
    // Initialize the index variable to 0
	i = 0;

    // Loop through the array of strings and print each string
	while (path[i])
	{
		ft_printf("%s\n", path[i]); // Print the current string
		i++; // Move to the next string in the array
	}
}
