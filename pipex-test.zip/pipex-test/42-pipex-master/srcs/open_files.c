/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   open_files.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:29:46 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:29:49 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to open an input file and return the file descriptor
int	open_infile(const char *filename)
{
	int	fd;

    // Open the file for reading only
	fd = open(filename, O_RDONLY);
    
    // Check if the file opening was unsuccessful
	if (fd == -1)
	{
        // Print an error message with the filename
		ft_putstr_fd("pipex: ", 2);
		perror(filename);
	}
    
    // Return the file descriptor
	return (fd);
}

// Function to open an output file and return the file descriptor
int	open_outfile(const char *filename)
{
	int	fd;

    // Open the file for writing only, truncate the existing content, and create if it does not exist
	fd = open(filename, O_WRONLY | O_TRUNC | O_CREAT, 0644);
    
    // Check if the file opening was unsuccessful
	if (fd == -1)
	{
        // Print an error message with the filename
		ft_putstr_fd("pipex: ", 2);
		perror(filename);
	}
    
    // Return the file descriptor
	return (fd);
}

// Function to open an output file for here_doc and return the file descriptor
int	here_doc_open_outfile(const char *filename)
{
	int	fd;

    // Open the file for writing only, append to existing content, and create if it does not exist
	fd = open(filename, O_WRONLY | O_APPEND | O_CREAT, 0644);
    
    // Check if the file opening was unsuccessful
	if (fd == -1)
	{
        // Print an error message with the filename
		ft_putstr_fd("pipex: ", 2);
		perror(filename);
	}
    
    // Return the file descriptor
	return (fd);
}
