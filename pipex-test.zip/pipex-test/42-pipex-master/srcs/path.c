/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:30:01 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:30:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to get the pointer to the PATH environment variable in envp
static char	*get_path_ptr(char *envp[])
{
	int		i;
	char	*ptr;

	i = 0;

    // Infinite loop to iterate through envp
	while (1)
	{
        // Get the current environment variable from envp
		ptr = envp[i];
        
        // Break if the end of envp is reached
		if (!ptr)
			break ;
        
        // Check if the current environment variable starts with "PATH="
		if (strncmp(ptr, "PATH=", 5) == 0)
			return (ptr); // Return the pointer to the PATH variable
		i++;
	}
    
    // Return NULL if PATH is not found in envp
	return (NULL);
}

// Function to extract and return the PATH variable as an array of strings
char	**get_path(char *envp[])
{
	char	*path_ptr;
	char	**path;

    // Get the pointer to the PATH variable in envp
	path_ptr = get_path_ptr(envp);
    
    // Move the pointer past "PATH=" to get the actual path value
	path_ptr += 5;
    
    // Split the path value into an array of strings using ':' as the delimiter
	path = ft_split(path_ptr, ':');
    
    // Return the array of strings representing the PATH
	return (path);
}
