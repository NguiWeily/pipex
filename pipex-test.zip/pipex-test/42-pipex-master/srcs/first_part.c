/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   first_part.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:28:57 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:28:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to handle the child process in the first part of the pipex command
static void	first_part_child(int fd[2], int pipefd[2], char *arg, t_env *env)
{
    // Close unused ends of the pipes
	close(pipefd[0]);
    
    // Redirect stdin to the input file descriptor
	dup2(fd[0], STDIN_FILENO);
    
    // Redirect stdout to the output end of the pipe
	dup2(pipefd[1], STDOUT_FILENO);
    
    // Execute the command using execute_cmd function
	execute_cmd(arg, env);
    
    // Cleanup resources and close the output end of the pipe
	end_pipex(fd, env->path);
	close(pipefd[1]);
    
    // Exit the child process
	exit(1);
}

// Function to handle the first part of the pipex command
int	first_part(int fd[2], int pipefd[2], char *arg, t_env *env)
{
	int	pid;

    // Create a pipe for communication between the processes
	if (pipe(pipefd) == -1)
		return (perror("pipex: pipe"), end_pipex(fd, env->path), 0);
    
    // Check if the input file descriptor is valid
	if (fd[0] == -1)
		return (1);

    // Create a child process
	pid = fork();

    // Check if fork failed
	if (pid == -1)
	{
        // Print error message and cleanup resources
		perror("pipex: fork");
		return (close(pipefd[0]), close(pipefd[1]), \
		end_pipex(fd, env->path), 0);
	}
	else if (pid == 0)
        // In the child process, call the first_part_child function
		first_part_child(fd, pipefd, arg, env);
    
    // In the parent process, return success
	return (1);
}

// Function to handle the first part of the here_doc pipex command
int	here_doc_first_part(int fd[2], int pipefd[2], char *arg, t_env *env)
{
	char	*line;

    // Create a pipe for communication between the processes
	if (pipe(pipefd) == -1)
		return (perror("pipex: pipe"), end_pipex(fd, env->path), 0);
    
    // Append a newline character to the argument
	arg = ft_strjoin(arg, "\n");
    
    // Prompt the user for input
	ft_putstr("> ");
    
    // Infinite loop to read lines from the input file descriptor
	while (1)
	{
        // Get the next line from the input file descriptor
		line = get_next_line(fd[0]);
        
        // Check if the line matches the appended argument
		if (line && ft_strcmp(line, arg) == 0)
		{
			free(line);
			break ;
		}
        // Check if the line contains a newline character
		else if (line && ft_strchr(line, '\n'))
			ft_putstr("> ");
        
        // Check if the line is not the appended argument and write to the output end of the pipe
		if (line && ft_strcmp(line, arg) != 0)
		{
			ft_putstr_fd(line, pipefd[1]);
			free(line);
		}
	}
    // Return success
	return (1);
}
