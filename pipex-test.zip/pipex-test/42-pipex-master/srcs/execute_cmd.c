/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute_cmd.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:28:43 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:28:46 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to try executing a command by searching in the PATH directories
static int	try_to_execute(t_env *env, char **args)
{
	size_t	i;
	char	*bin;

	i = 0;
    // Attempt to execute the command using execve with the given arguments
	execve(args[0], args, env->envp);
    
    // Loop through PATH directories and attempt to execute the command
	while (1)
	{
        // Break if the end of the PATH array is reached
		if (!((env->path)[i]))
			break ;
        
        // Construct the full path to the command in the current PATH directory
		bin = ft_strrjoin((env->path)[i], "/", args[0]);
		if (!bin)
			return (ft_putstr_fd(ERR_ALLOC, 2), free_tabstr(args), 0);
        
        // Attempt to execute the command with the full path
		if (execve(bin, args, env->envp) <= 0)
		{
			free(bin);
			bin = NULL;
		}
		i++;
	}
    // Return 1 to indicate successful execution
	return (1);
}

// Main function to execute a command with the given environment
int	execute_cmd(char *cmd, t_env *env)
{
	char	**args;
	int		status;
	char	*err;

    // Check if the command is empty or consists only of spaces
	if (!cmd || ft_strlen(cmd) == 0 || ft_countc(cmd, ' ') == ft_strlen(cmd))
		return (ft_putstr_fd("pipex: command not found:\n", 2), 0);

    // Split the command into an array of arguments
	args = ft_split(cmd, ' ');
	if (!args)
		return (ft_putstr_fd(ERR_ALLOC, 2), 0);

    // Try to execute the command and get the status
	status = try_to_execute(env, args);

    // Check if execution was unsuccessful
	if (status == 0)
		return (0);

    // Print an error message if the command was not found
	err = ft_strrjoin("pipex: command not found: ", args[0], "\n");
	ft_putstr_fd(err, 2);
    
    // Free the allocated memory for the error message
	if (err)
		free(err);

    // Free the memory allocated for the array of arguments
	return (free_tabstr(args), status);
}
