/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   last_part.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:29:10 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:29:12 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to handle the last part of the pipex command
int	last_part(int fd[2], int pipefd[2], char *arg, t_env *env)
{
	int	pid;
	int	status;

    // Close the output end of the pipe
	close(pipefd[1]);
    
    // Create a child process
	pid = fork();
    
    // Check if fork failed
	if (pid == -1)
	{
        // Print error message and cleanup resources
		return (perror("pipex: fork"), \
		close(pipefd[0]), close(pipefd[1]), end_pipex(fd, env->path), 0);
	}
	else if (pid == 0)
	{
        // In the child process, redirect stdin to the input end of the pipe
		dup2(pipefd[0], STDIN_FILENO);
        
        // Redirect stdout to the output file descriptor
		dup2(fd[1], STDOUT_FILENO);
        
        // Execute the command using execute_cmd function
		status = execute_cmd(arg, env);
        
        // Close the input end of the pipe and cleanup resources
		close(pipefd[0]);
		end_pipex(fd, env->path);
        
        // Exit the child process with the status returned by execute_cmd
		exit(status);
	}
	else
	{
        // In the parent process, wait for the child process to complete
		wait(&status);
        
        // Close the input end of the pipe
		close(pipefd[0]);
	}
    
    // Return the status of the last executed command
	return (status);
}
