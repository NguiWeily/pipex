/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:30:16 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:30:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h" // Include the header file "pipex.h"

// Function to wait for child processes to complete
static void	wait_childs(void)
{
    // Infinite loop to wait for child processes
	while (1)
		if (wait(NULL) <= 0)
			return ;
}

// Main function for executing the pipex command
static int	pipex(char **args, int size, t_env *env)
{
	int		fd[2];
	int		pipefd[2];
	int		middle_cmds;
	size_t	i;
	int		return_value;

    // Initialize file descriptors
	fd[1] = -1;
	fd[0] = open_infile(args[0]); // Open the input file

    // Check the first part of the command
	if (!first_part(fd, pipefd, args[1], env))
		return (1);

    // Calculate the number of middle commands
	middle_cmds = size - 4;
	i = 1;

    // Loop through and execute middle commands
	while (middle_cmds-- > 0)
		middle_part(fd, pipefd, args[1 + i++], env);

    // Close input file descriptor
	if (fd[0] > 0)
		close(fd[0]);

    // Reset file descriptors for output
	fd[0] = -1;
	fd[1] = open_outfile(args[size - 1]); // Open the output file

    // Check the last part of the command
	if (fd[1] == -1)
		return (end_pipex(fd, env->path), 1);

    // Execute the last part of the command
	return_value = last_part(fd, pipefd, args[size - 2], env);

    // Wait for child processes to complete
	wait_childs();

    // Cleanup and return
	return (end_pipex(fd, env->path), return_value);
}

// Function to execute the here_doc command
static int	here_doc(char **args, int size, t_env *env)
{
	int		fd[2];
	int		pipefd[2];
	int		middle_cmds;
	size_t	i;
	int		return_value;

    // Set input file descriptor to stdin
	fd[0] = 0;

    // Check the first part of the here_doc command
	if (!here_doc_first_part(fd, pipefd, args[1], env))
		return (1);

    // Calculate the number of middle commands
	middle_cmds = size - 4;
	i = 1;

    // Loop through and execute middle commands
	while (middle_cmds > 0)
	{
		middle_part(fd, pipefd, args[1 + i], env);
		middle_cmds--;
		i++;
	}

    // Open the output file for here_doc
	fd[1] = here_doc_open_outfile(args[size - 1]);

    // Check if output file opened successfully
	if (fd[1] == -1)
		return (end_pipex(fd, env->path), 1);

    // Execute the last part of the here_doc command
	return_value = last_part(fd, pipefd, args[size - 2], env);

    // Cleanup and return
	return (end_pipex(fd, env->path), return_value);
}

// Main function
int	main(int argc, char **argv, char *envp[])
{
	t_env	env;

    // Check for the correct number of arguments
	if (argc < 5 || (argc > 1 && argc < 6 \
	&& ft_strcmp(argv[1], "here_doc") == 0))
		return (ft_putstr_fd(ERR_NOTENOUGHARGS, 2), 1);

    // Set environment variables
	env.envp = envp;
	env.path = get_path(envp);

    // Check if path is not found
	if (!(env.path))
		return (ft_putstr_fd(ERR_PATHNOTFOUND, 2), 1);

    // Check if the command is here_doc
	else if (ft_strcmp(argv[1], "here_doc") == 0)
		return (here_doc(argv + 1, argc - 1, &env));

    // Otherwise, execute the pipex command
	else
		return (pipex(argv + 1, argc - 1, &env));
}
