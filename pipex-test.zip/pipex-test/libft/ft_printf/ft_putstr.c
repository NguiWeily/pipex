/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:02:51 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:02:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to write a string to the standard output.
size_t ft_putstr(const char *str)
{
    if (!str) // If the string is NULL.
        return (write(1, "(null)", 6)); // Write "(null)" to the standard output and return the number of bytes written.
    else // If the string is not NULL.
        return (write(1, str, ft_strlen(str))); // Write the string to the standard output and return the number of bytes written.
}
