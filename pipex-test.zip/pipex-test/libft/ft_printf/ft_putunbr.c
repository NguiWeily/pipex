/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putunbr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:03:11 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:03:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to recursively print each digit of an unsigned integer.
size_t ft_putunbr(const unsigned int n)
{
    if (n / 10) // If there are more digits in the number.
        return (ft_putunbr(n / 10) + ft_putunbr(n % 10)); // Recursively print each digit.
    else // If it's the last digit.
        return (ft_putchar(n + '0')); // Print the digit as a character.
}
