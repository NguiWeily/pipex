/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:01:10 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:01:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h" // Include the header file containing function declarations.

// Function to write a single character to the standard output.
size_t ft_putchar(const char c)
{
    return (write(1, &c, 1)); // Write the character 'c' to the standard output (file descriptor 1) and return the number of bytes written.
}
