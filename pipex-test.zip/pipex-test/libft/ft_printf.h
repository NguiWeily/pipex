/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:03:51 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:03:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H // Header guard to prevent multiple inclusion of the header file.
# define FT_PRINTF_H // Define the header file if not defined already.

# include "libft.h" // Including the header file for the library functions.

# include <stdarg.h> // Including the header file for variable arguments handling.
# include <string.h> // Including the header file for string manipulation functions.
# include <stdlib.h> // Including the header file for standard library functions.
# include <unistd.h> // Including the header file for standard I/O functions.

int		ft_printf(const char *str, ...); // Declaration of the printf function with variable arguments.

size_t	ft_putadress(void *adress); // Declaration of function to print memory address.
size_t	ft_putchar(const char c); // Declaration of function to print a character.
size_t	ft_puthexa_lower(const unsigned int n); // Declaration of function to print hexadecimal in lowercase.
size_t	ft_puthexa_upper(const unsigned int n); // Declaration of function to print hexadecimal in uppercase.
size_t	ft_putnbr(const int n); // Declaration of function to print an integer.
size_t	ft_putstr(const char *str); // Declaration of function to print a string.
size_t	ft_putunbr(const unsigned int n); // Declaration of function to print an unsigned integer.

#endif // End of header guard.
