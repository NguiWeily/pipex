/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:23:45 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:23:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_lstadd_back(t_list **alst, t_list *new) // Define a function named ft_lstadd_back that takes a pointer to a pointer to a t_list (alst) and a pointer to a t_list (new) as arguments.
{
	if (!alst || !new) // Check if either alst or new is NULL.
		return; // If either alst or new is NULL, exit the function.

	if (*alst) // If *alst (the pointer to the head of the list) is not NULL,
		ft_lstlast(*alst)->next = new; // Set the next pointer of the last node in the list to the new node.
	else // If *alst is NULL, meaning the list is empty,
		*alst = new; // Set *alst to point to the new node, making it the first node in the list.
}
