/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstiter_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:10:04 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:10:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

##include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_lstiter(t_list *lst, void (*f)(void *)) // Define a function named ft_lstiter that takes a pointer to a t_list (lst) and a function pointer f as arguments.
{
	while (lst && f) // Continue the loop as long as lst is not NULL and f is not NULL.
	{
		f(lst->content); // Call the function pointer f on the content of the current node.
		lst = lst->next; // Move to the next node in the list.
	}
}
