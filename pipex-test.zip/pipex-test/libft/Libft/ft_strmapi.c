/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:11:26 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:11:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strmapi that applies the function f to each character of the string s, along with its index.
char *ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	size_t i; // Declare a variable to iterate through the characters of the string.
	char *new; // Declare a pointer to store the modified string.

	new = malloc(sizeof(char) * (ft_strlen(s) + 1)); // Allocate memory for the modified string, including space for the null terminator.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i]) // Iterate through the characters of the string until reaching the null terminator.
	{
		new[i] = (*f)(i, s[i]); // Apply the function f to each character of the string s, along with its index, and store the result in the modified string new.
		i++; // Increment the iterator to move to the next character in the string.
	}
	new[i] = '\0'; // Add a null terminator at the end of the modified string.
	return (new); // Return a pointer to the modified string.
}
