/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:23:16 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:23:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_swap that swaps the values of two long integers pointed to by a and b.
void ft_swap(long *a, long *b)
{
    long tmp; // Declare a temporary variable to hold the value of one of the integers.

    tmp = *a; // Store the value of the integer pointed to by a in the temporary variable tmp.
    *a = *b; // Assign the value of the integer pointed to by b to the integer pointed to by a.
    *b = tmp; // Assign the value stored in the temporary variable tmp to the integer pointed to by b, effectively swapping their values.
}
