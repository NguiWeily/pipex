/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:17:28 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:17:31 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a static function named count_words that counts the number of words in a string s separated by the character c.
static size_t count_words(char const *s, char c)
{
	size_t words; // Declare a variable to store the count of words.
	size_t i; // Declare a variable to iterate through the characters of the string.

	words = 0; // Initialize the word count to 0.
	i = 0; // Initialize the iterator variable to 0.
	while (s[i]) // Iterate through the characters of the string until reaching the null terminator.
	{
		if (s[i] != c && (s[i + 1] == c || s[i + 1] == '\0')) // Check if the current character is not c and the next character is c or null terminator.
			words++; // If so, increment the word count.
		i++; // Increment the iterator to move to the next character in the string.
	}
	return (words); // Return the total count of words.
}

// Define a static function named fill_tab that fills a string new with characters from s until the character c is encountered.
static void fill_tab(char *new, char const *s, char c)
{
	size_t i; // Declare a variable to iterate through the characters of the string.

	i = 0; // Initialize the iterator variable to 0.
	while (s[i] && s[i] != c) // Iterate through the characters of the string until reaching the null terminator or character c.
	{
		new[i] = s[i]; // Copy the current character from s to new.
		i++; // Increment the iterator to move to the next character in the string.
	}
	new[i] = '\0'; // Add a null terminator at the end of the new string.
}

// Define a function named free_tabstr that frees the memory allocated for an array of strings tab.
void free_tabstr(char **tab)
{
	size_t i; // Declare a variable to iterate through the array of strings.

	if (!tab) // Check if tab is NULL.
		return; // If tab is NULL, exit the function.

	i = 0; // Initialize the iterator variable to 0.
	while (tab[i]) // Iterate through the array of strings until reaching a NULL pointer.
	{
		free(tab[i]); // Free the memory allocated for the current string.
		i++; // Increment the iterator to move to the next string in the array.
	}
	free(tab); // Free the memory allocated for the array of strings.
}

// Define a static function named set_mem that allocates memory for an array of strings tab and fills it with words from the string s separated by the character c.
static int set_mem(char **tab, char const *s, char c)
{
	size_t count; // Declare a variable to store the count of characters in a word.
	size_t index; // Declare a variable to track the current position in the string.
	size_t i; // Declare a variable to iterate through the array of strings.

	index = 0; // Initialize the index variable to 0.
	i = 0; // Initialize the iterator variable to 0.
	while (s[index]) // Iterate through the characters of the string until reaching the null terminator.
	{
		count = 0; // Initialize the count variable to 0.
		while (s[index + count] && s[index + count] != c) // Iterate through the characters of the word until reaching the null terminator or character c.
			count++; // Increment the count to track the number of characters in the word.
		if (count > 0) // Check if a word has been found.
		{
			tab[i] = malloc(sizeof(char) * (count + 1)); // Allocate memory for the current word plus the null terminator.
			if (!tab[i]) // Check if memory allocation failed.
				return (free_tabstr(tab), 0); // If memory allocation failed, free the allocated memory and return 0.
			fill_tab(tab[i], (s + index), c); // Fill the current word in the array with characters from the string.
			i++; // Increment the iterator to move to the next slot in the array.
			index = index + count; // Move the index to the next character after the current word.
		}
		else // If no word is found,
			index++; // Move the index to the next character in the string.
	}
	tab[i] = 0; // Add a NULL pointer at the end of the array of strings to indicate the end.
	return (1); // Return 1 to indicate success.
}

// Define a function named ft_split that splits a string s into an array of strings based on the delimiter character c.
char **ft_split(char const *s, char c)
{
	size_t words; // Declare a variable to store the count of words.
	char **tab; // Declare a pointer to an array of strings.

	words = count_words(s, c); // Count the number of words in the string.
	tab = malloc(sizeof(char *) * (words + 1)); // Allocate memory for the array of strings plus an additional NULL pointer.
	if (!tab) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.
	set_mem(tab, s, c); // Fill the array of strings with words from the string.
	return (tab); // Return a pointer to the array of strings.
}
