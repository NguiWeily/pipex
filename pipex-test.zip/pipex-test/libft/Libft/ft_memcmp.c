/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:22:31 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:22:33 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

int ft_memcmp(const void *s1, const void *s2, size_t n) // Define a function named ft_memcmp that compares the first n bytes of two memory areas pointed to by s1 and s2.
{
	size_t i; // Declare a variable to iterate through the memory areas.

	i = 0; // Initialize the iterator variable to 0.
	while (i < n && *(unsigned char *)(s1 + i) == *(unsigned char *)(s2 + i)) // Iterate through the memory areas as long as there are remaining bytes to compare and the corresponding bytes in s1 and s2 are equal.
		i++; // Increment the iterator to move to the next byte in the memory areas.

	if (i < n) // Check if there are remaining bytes to compare.
		return (*(unsigned char *)(s1 + i) - *(unsigned char *)(s2 + i)); // If a difference is found, return the difference between the first differing bytes.
	
	return (0); // If all bytes are equal, return 0 to indicate that the memory areas are equal.
}
