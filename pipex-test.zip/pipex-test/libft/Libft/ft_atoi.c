/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:06:48 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:06:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Including the header file that contains function prototypes and structure definitions.

int	ft_atoi(const char *str) // Function to convert a string to an integer.
{
	int		nbr; // Variable to store the resulting integer.
	int		sign; // Variable to store the sign of the integer.
	size_t	i; // Variable for iterating through the string.

	nbr = 0; // Initializing the integer to 0.
	sign = 1; // Initializing the sign to positive.
	i = 0; // Initializing the index to 0.
	while (str[i] == ' ' || ('\t' <= str[i] && str[i] <= '\r')) // Skipping whitespace characters.
		i++;
	if (str[i] == '+') // Handling positive sign.
		i++;
	else if (str[i] == '-') // Handling negative sign.
	{
		sign *= -1;
		i++;
	}
	while ('0' <= str[i] && str[i] <= '9') // Converting digits to integer.
	{
		nbr = nbr * 10 + str[i] - '0';
		i++;
	}
	return (nbr * sign); // Returning the final integer with sign.
}
