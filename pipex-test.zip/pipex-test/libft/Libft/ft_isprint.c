/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:20:08 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:20:11 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

int ft_isprint(int c) // Define a function named ft_isprint that takes an integer argument c.
{
	if (c >= 32 && 126 >= c) // Check if the integer c falls within the printable ASCII range (32 to 126).
		return (1); // If c is a printable character, return 1 to indicate true.
	else
		return (0); // If c is not a printable character, return 0 to indicate false.
}
