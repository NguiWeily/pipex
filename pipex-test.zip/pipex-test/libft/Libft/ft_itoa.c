/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:21:58 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:22:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a static function named count_size that takes a long integer argument nb and returns a size_t value.
static size_t count_size(long nb)
{
	size_t size; // Declare a variable to store the size of the number.

	size = 0; // Initialize the size variable to 0.
	if (nb < 0) // If the number is negative,
	{
		nb = nb * (-1); // Convert it to its positive equivalent.
		size = 1; // Increment the size to account for the negative sign.
	}
	if (nb == 0) // If the number is 0,
		size = 1; // Set the size to 1.
	else // If the number is non-zero,
	{
		while (nb) // Loop until the number becomes 0.
		{
			nb = nb / 10; // Divide the number by 10 to move to the next digit.
			size++; // Increment the size to count the digits.
		}
	}
	return (size); // Return the calculated size.
}

// Define a function named ft_itoa that converts an integer to a string.
char *ft_itoa(int n)
{
	size_t size; // Declare a variable to store the size of the resulting string.
	long nb; // Declare a variable to store the input number.
	char *str; // Declare a pointer to a character array to store the resulting string.
	int is_negative; // Declare a variable to store whether the input number is negative.

	size = count_size((long) n); // Calculate the size required for the string representation of the number.
	str = (char *) malloc(sizeof(char) * (size + 1)); // Allocate memory for the string, including space for the null terminator.
	if (str == NULL) // If memory allocation fails,
		return (NULL); // Return NULL to indicate failure.
	nb = (long) n; // Convert the input integer to a long integer.
	is_negative = 0; // Initialize the is_negative flag to 0.
	if (nb < 0) // If the number is negative,
	{
		nb = nb * (-1); // Convert it to its positive equivalent.
		str[0] = '-'; // Set the first character of the string as the negative sign.
		is_negative = 1; // Set the is_negative flag to indicate that the number is negative.
	}
	str[size] = '\0'; // Set the last character of the string as the null terminator.
	while (size > (size_t) is_negative) // Iterate over each digit of the number.
	{
		str[size - 1] = nb % 10 + '0'; // Convert the last digit to its character representation and store it in the string.
		nb = nb / 10; // Move to the next digit by dividing the number by 10.
		size--; // Decrement the size to move to the next position in the string.
	}
	return (str); // Return the resulting string.
}

