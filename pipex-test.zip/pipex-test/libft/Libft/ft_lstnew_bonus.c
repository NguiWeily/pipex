/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:16:38 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:16:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

t_list *ft_lstnew(void *content) // Define a function named ft_lstnew that takes a pointer to void (content) as an argument and returns a pointer to a new list node.
{
	t_list *new; // Declare a pointer to store the new list node.

	new = malloc(sizeof(t_list)); // Allocate memory for the new list node.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	new->content = content; // Set the content of the new node to the provided content.
	new->next = NULL; // Set the next pointer of the new node to NULL, indicating that it is the last node in the list.

	return (new); // Return a pointer to the new list node.
}
