/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:09:43 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:09:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Including the header file that contains function prototypes and structure definitions.

static void	*ft_memalloc(size_t size) // Function to allocate memory and initialize it to zero.
{
	void	*new; // Pointer to the allocated memory.
	size_t	i; // Variable for iterating through the memory block.

	new = (void *) malloc(size); // Allocating memory of the specified size.
	if (!new) // Checking if memory allocation was successful.
		return (NULL); // Returning NULL if allocation failed.
	i = 0; // Initializing the index to 0.
	while (i < size) // Looping through each byte of the allocated memory.
	{
		*(unsigned char *)(new + i) = 0; // Setting each byte to 0.
		i++; // Moving to the next byte.
	}
	return (new); // Returning the pointer to the allocated memory.
}

void	*ft_calloc(size_t count, size_t size) // Function to allocate and zero-initialize memory for an array.
{
	if (size != 0 && count > ((size_t) -1 / size)) // Checking for potential overflow.
		return (NULL); // Returning NULL if overflow might occur.
	return (ft_memalloc(count * size)); // Calling ft_memalloc to allocate and initialize memory.
}
