/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:17:51 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:17:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strrchr that finds the last occurrence of the character c in the string s.
char *ft_strrchr(const char *s, int c)
{
	int i; // Declare a variable to iterate through the characters of the string.

	if (!s) // Check if the string s is NULL.
		return (NULL); // If the string s is NULL, return NULL.

	i = ft_strlen(s); // Get the length of the string s.
	while (i >= 0) // Iterate through the characters of the string from the end to the beginning.
	{
		if (s[i] == (char) c) // Check if the current character is equal to the character c.
			return ((char *) s + i); // If the character is found, return a pointer to the position of the character in the string.
		i--; // Decrement the iterator to move to the previous character in the string.
	}
	return (NULL); // If the character c is not found in the string s, return NULL.
}
