/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:07:47 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:07:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_strlcpy that copies the string src to the string dst with a specified maximum size dstsize.
size_t ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
	size_t i; // Declare a variable to iterate through the characters of the source string src.

	i = 0; // Initialize the iterator variable to 0.
	if (!dst || !src) // Check if either the destination string or the source string is NULL.
		return (0); // If either the destination string or the source string is NULL, return 0.

	while (src[i] && i + 1 < dstsize) // Iterate through the characters of the source string until reaching the null terminator or the maximum size.
	{
		dst[i] = src[i]; // Copy each character from the source string src to the destination string dst.
		i++; // Increment the iterator to move to the next character in the source string.
	}

	if (dstsize > 0) // Check if the maximum size is greater than 0.
	{
		dst[i] = '\0'; // Add a null terminator at the end of the destination string dst.
		i++; // Increment the iterator to move to the position after the null terminator.
	}

	return (ft_strlen(src)); // Return the length of the source string src.
}
