/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:26:33 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:26:36 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_toupper that converts a lowercase letter to uppercase if applicable.
int ft_toupper(int c)
{
    if (c >= 'a' && 'z' >= c) // Check if the character is a lowercase letter.
        return (c - 'a' + 'A'); // If so, convert the lowercase letter to uppercase and return the result.
    return (c); // If the character is not a lowercase letter, return it unchanged.
}
