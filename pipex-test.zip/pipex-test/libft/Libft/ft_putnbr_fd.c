/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:12:57 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:13:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

static void print_nb(long nb, int fd) // Define a static function named print_nb that recursively prints a long integer to the file descriptor fd.
{
	if (nb / 10) // Check if there are more digits to print.
	{
		print_nb(nb / 10, fd); // Recursively call print_nb to print the remaining digits.
		print_nb(nb % 10, fd); // Print the last digit.
	}
	else // If nb is a single digit,
		ft_putchar_fd(nb + '0', fd); // Write the digit to the file descriptor fd.
}

void ft_putnbr_fd(int n, int fd) // Define a function named ft_putnbr_fd that writes an integer n to the file descriptor fd.
{
	long nb; // Declare a variable to store the integer as a long.

	nb = n; // Convert the integer n to a long and store it in nb.
	if (nb < 0) // If nb is negative,
	{
		write(fd, "-", 1); // Write a negative sign to the file descriptor fd.
		nb = -nb; // Convert nb to its positive equivalent.
	}
	print_nb(nb, fd); // Print the positive integer nb to the file descriptor fd.
}
