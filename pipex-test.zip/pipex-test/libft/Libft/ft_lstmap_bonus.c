/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:14:33 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:14:39 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

t_list *ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *)) // Define a function named ft_lstmap that takes a pointer to a t_list (lst), a function pointer f, and a function pointer del as arguments, and returns a pointer to a new list.
{
	t_list *start; // Declare a pointer to the start of the new list.
	t_list *current; // Declare a pointer to the current node in the new list.

	if (!lst || !f || !del) // Check if any of the arguments are NULL.
		return (NULL); // If any of the arguments are NULL, return NULL.

	start = ft_lstnew(f(lst->content)); // Create a new node for the start of the list by applying the function f to the content of the first node in the original list.
	current = start; // Set the current pointer to point to the start of the new list.

	while (lst && lst->next) // Iterate through the original list until the end.
	{
		if (!current) // Check if current is NULL.
			return (NULL); // If current is NULL, return NULL.

		current->next = ft_lstnew(f(lst->next->content)); // Create a new node in the new list by applying the function f to the content of the next node in the original list.
		current = current->next; // Move the current pointer to the next node in the new list.
		lst = lst->next; // Move to the next node in the original list.
	}

	return (start); // Return a pointer to the start of the new list.
}
