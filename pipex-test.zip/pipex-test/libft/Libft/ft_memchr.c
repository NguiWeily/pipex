/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:20:32 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:20:35 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void *ft_memchr(const void *s, int c, size_t n) // Define a function named ft_memchr that searches for a character in the first n bytes of the memory area pointed to by s.
{
	size_t i; // Declare a variable to iterate through the memory area.

	i = 0; // Initialize the iterator variable to 0.
	while (i < n) // Iterate through the memory area until i reaches n.
	{
		if (*(unsigned char *)(s + i) == (unsigned char)c) // Check if the current byte in the memory area matches the specified character c.
			return ((void *)s + i); // If a match is found, return a pointer to the matching byte.
		i++; // Increment the iterator to move to the next byte in the memory area.
	}
	return (NULL); // If no match is found within the specified range, return NULL.
}
