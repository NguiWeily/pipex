/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:08:05 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:08:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Including the header file that contains function prototypes and structure definitions.

void	ft_bzero(void *s, size_t n) // Function to zero out bytes in a memory block.
{
	size_t	i; // Variable for iterating through the memory block.

	i = 0; // Initializing the index to 0.
	while (i < n) // Looping through each byte of the memory block.
	{
		*(unsigned char *)(s + i) = 0; // Setting each byte to 0.
		i++; // Moving to the next byte.
	}
}
