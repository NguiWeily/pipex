/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear_bonus.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:07:10 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:07:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

void ft_lstclear(t_list **lst, void (*del)(void *)) // Define a function named ft_lstclear that takes a pointer to a pointer to a t_list (lst) and a function pointer del as arguments.
{
	if (!lst || !(*lst) || !del) // Check if lst is NULL, if the list pointed to by lst is empty, or if del is NULL.
		return; // If any of these conditions are true, exit the function.

	if ((*lst)->next) // If the list has more than one node,
		ft_lstclear((&(*lst)->next), del); // Recursively call ft_lstclear on the next node in the list.

	del((*lst)->content); // Call the del function pointer on the content of the current node to free any allocated memory associated with it.
	free(*lst); // Free the memory allocated for the current node.
	*lst = NULL; // Set the pointer to the current node to NULL to indicate that it no longer points to a valid node.
}
