/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:25:11 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:25:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_tolower that converts an uppercase letter to lowercase if applicable.
int ft_tolower(int c)
{
    if (c >= 'A' && 'Z' >= c) // Check if the character is an uppercase letter.
        return (c + 'a' - 'A'); // If so, convert the uppercase letter to lowercase and return the result.
    return (c); // If the character is not an uppercase letter, return it unchanged.
}
