/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstlast_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:12:24 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:12:26 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

t_list *ft_lstlast(t_list *lst) // Define a function named ft_lstlast that takes a pointer to a t_list (lst) as an argument and returns a pointer to the last node in the list.
{
	while (lst && lst->next) // Iterate through the list until lst is NULL or lst->next is NULL.
		lst = lst->next; // Move to the next node in the list.

	return (lst); // Return a pointer to the last node in the list.
}
