/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:21:35 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:21:38 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h" // Include the header file "libft.h", which likely contains declarations for functions used in this file.

// Define a function named ft_substr that creates a substring of a given string s starting from the index start with a specified length len.
char *ft_substr(char const *s, unsigned int start, size_t len)
{
	char *new; // Declare a pointer to store the new substring.
	unsigned int i; // Declare a variable to iterate through the characters of the substring.

	if (start >= ft_strlen(s)) // Check if the start index is greater than or equal to the length of the string s.
		len = 0; // If so, set the length of the substring to 0.
	else if (len > ft_strlen(s + start)) // Check if the specified length exceeds the remaining length of the string s from the start index.
		len = ft_strlen(s + start); // If so, adjust the length of the substring to the remaining length of the string.

	new = malloc(sizeof(char) * (len + 1)); // Allocate memory for the new substring, including space for the null terminator.
	if (!new) // Check if memory allocation failed.
		return (NULL); // If memory allocation failed, return NULL.

	i = 0; // Initialize the iterator variable i to 0.
	while (start + i < ft_strlen(s) && i < len) // Iterate through the characters of the substring until reaching the end of the string s or the specified length.
	{
		new[i] = s[start + i]; // Copy each character from the string s to the substring starting from the specified index start.
		i++; // Increment the iterator to move to the next character.
	}
	new[i] = '\0'; // Add the null terminator to the end of the substring.
	return (new); // Return a pointer to the new substring.
}
