/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:04:48 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:04:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h" // Including the header file that declares structures and function prototypes.

t_bufferList *ftlst_new_buffer(void) // Function to create a new buffer node.
{
    t_bufferList *new; // Declaring a pointer to a buffer node.

    new = malloc(sizeof(t_bufferList)); // Allocating memory for the new buffer node.
    if (!new) // Checking if memory allocation was successful.
        return (NULL); // Returning NULL if memory allocation failed.

    new->content = malloc(BUFFER_SIZE + 1); // Allocating memory for the content of the buffer node.
    if (!(new->content)) // Checking if memory allocation was successful.
        return (free(new), NULL); // Freeing previously allocated memory and returning NULL if allocation failed.

    (new->content)[0] = '\0'; // Setting the first character of content to null terminator.
    new->next = 0; // Initializing the next pointer to NULL.

    return (new); // Returning a pointer to the newly created buffer node.
}

t_fdList *ftlst_new_fd(int fd) // Function to create a new file descriptor node.
{
    t_fdList *new; // Declaring a pointer to a file descriptor node.

    new = malloc(sizeof(t_fdList)); // Allocating memory for the new file descriptor node.
    if (!new) // Checking if memory allocation was successful.
        return (NULL); // Returning NULL if memory allocation failed.

    new->fd = fd; // Assigning the file descriptor.
    new->begin = ftlst_new_buffer(); // Creating a new buffer node for the file descriptor.
    if (!(new->begin)) // Checking if memory allocation for the buffer node failed.
        return (free(new), NULL); // Freeing previously allocated memory and returning NULL if allocation failed.

    new->next_fd = 0; // Initializing the next file descriptor pointer to NULL.

    return (new); // Returning a pointer to the newly created file descriptor node.
}

int end_of_line(char *content) // Function to check if end of line is reached in buffer content.
{
    size_t i; // Declaring a variable to hold the index.

    i = 0; // Initializing the index to 0.
    while (content[i]) // Looping through the content until null terminator is encountered.
    {
        if (content[i] == '\n') // Checking if newline character is found.
            return (1); // Returning 1 if newline character is found.
        i++; // Incrementing the index.
    }
    return (0); // Returning 0 if newline character is not found.
}

size_t count_memory(t_bufferList *current) // Function to count the total memory required to store content of all buffer nodes.
{
    size_t memory; // Declaring a variable to hold the memory count.
    size_t i; // Declaring a variable to hold the index.

    memory = 1; // Initializing memory count to 1 to account for null terminator.
    while (current) // Looping through all buffer nodes.
    {
        i = 0; // Initializing the index to 0.
        while ((current->content)[i]) // Looping through the content until null terminator is encountered.
        {
            memory++; // Incrementing the memory count for each character.
            i++; // Incrementing the index.
            if ((current->content)[i - 1] == '\n') // Checking if newline character is found.
                break; // Exiting the loop if newline character is found.
        }
        if (i > 0 && (current->content)[i - 1] == '\n') // Checking if newline character is found at the end of content.
        {
            i++; // Incrementing the index to account for newline character.
            break; // Exiting the loop.
        }
        current = current->next; // Moving to the next buffer node.
    }
    return (memory); // Returning the total memory count.
}

t_fdList *clean_fd_list(t_fdList *fd_list, t_fdList *c_fd) // Function to clean up file descriptor list.
{
    t_fdList *tmp; // Declaring a temporary pointer to traverse the list.

    if (!((c_fd->begin->content)[0])) // Checking if the content of the first buffer node is empty.
    {
        free(c_fd->begin->content); // Freeing memory allocated for the content of the buffer node.
        free(c_fd->begin); // Freeing memory allocated for the buffer node.
        if (fd_list == c_fd) // Checking if the file descriptor node to be removed is the head of the list.
            fd_list = fd_list->next_fd; // Updating the head of the list.
        else
        {
            tmp = fd_list; // Assigning the head of the list to the temporary pointer.
            while (tmp->next_fd && tmp->next_fd != c_fd) // Looping until the next file descriptor node is found.
                tmp = tmp->next_fd; // Moving to the next file descriptor node.
            if (tmp->next_fd) // Checking if the next file descriptor node is found.
                tmp->next_fd = tmp->next_fd->next_fd; // Removing the file descriptor node from the list.
        }
        free(c_fd); // Freeing memory allocated for the file descriptor node.
    }
    return (fd_list); // Returning the updated file descriptor list.
}
