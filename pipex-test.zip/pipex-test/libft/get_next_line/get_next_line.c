/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:04:19 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:04:25 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h" // Include the header file containing function declarations.

// Function to find or create a file descriptor node in the list.
static t_fdList *find_fdbegin(int fd, t_fdList **fd_list)
{
	t_fdList *current;

	if (!(*fd_list)) // If the list is empty.
		*fd_list = ftlst_new_fd(fd); // Create a new node for the file descriptor.
	if (!(*fd_list)) // If creation failed.
		return (NULL); // Return NULL.
	current = *fd_list; // Start from the beginning of the list.
	while (current->next_fd && current->fd != fd) // Iterate until end of list or matching fd is found.
		current = current->next_fd; // Move to the next node.
	if (current->fd != fd) // If the matching fd is not found.
	{
		current->next_fd = ftlst_new_fd(fd); // Create a new node for the fd.
		current = current->next_fd; // Move to the new node.
	}
	return (current); // Return the node with the matching or newly created fd.
}

// Function to read data from a file descriptor and store it in buffer nodes.
static int read_file(int fd, t_bufferList *begin, t_bufferList *current)
{
	int readed;

	readed = 0; // Initialize variable to store the number of bytes read.
	if (begin && end_of_line(begin->content)) // If there is a buffer and it contains a complete line.
		return (1); // Return 1 to indicate a complete line is available.
	else if (begin && (begin->content[0])) // If there is a buffer with partial data.
	{
		begin->next = ftlst_new_buffer(); // Create a new buffer node.
		current = begin->next; // Move to the new buffer node.
	}
	while (1) // Infinite loop to read data from the file descriptor.
	{
		readed = read(fd, current->content, BUFFER_SIZE); // Read data from the file descriptor.
		if (readed <= 0) // If end of file or error is reached.
			break; // Exit the loop.
		(current->content)[readed] = '\0'; // Null-terminate the buffer.
		if (end_of_line(current->content)) // If a complete line is read.
			break; // Exit the loop.
		current->next = ftlst_new_buffer(); // Create a new buffer node for more data.
		current = current->next; // Move to the new buffer node.
	}
	if (!(begin->content[0])) // If no data is read.
		return (0); // Return 0 to indicate end of file.
	return (1); // Return 1 to indicate a complete line is available.
}

// Function to concatenate content of buffer nodes into a single string.
static char *join_buffers(t_bufferList *current)
{
	char *line;
	size_t i;
	size_t j;

	line = malloc(count_memory(current)); // Allocate memory for the concatenated string.
	if (!line) // If memory allocation fails.
		return (NULL); // Return NULL.
	i = 0; // Initialize index for the concatenated string.
	while (current && current->content) // Iterate through buffer nodes until end.
	{
		j = 0; // Initialize index for the buffer content.
		while ((current->content)[j] && (i == 0 || line[i - 1] != '\n')) // Iterate through buffer content until end or newline.
			line[i++] = (current->content)[j++]; // Copy characters to the concatenated string.
		current = current->next; // Move to the next buffer node.
	}
	line[i] = '\0'; // Null-terminate the concatenated string.
	return (line); // Return the concatenated string.
}

// Function to clean up buffer nodes after reading data.
static void clean_buffers(t_bufferList *current, t_fdList *current_fd)
{
	size_t i;
	size_t j;
	t_bufferList *next;

	while (current->next) // Iterate through buffer nodes until end.
	{
		next = current->next; // Store the next buffer node.
		free(current->content); // Free memory allocated for buffer content.
		free(current); // Free memory allocated for the buffer node.
		current = next; // Move to the next buffer node.
		current_fd->begin = next; // Update the beginning of buffer list in file descriptor node.
	}
	i = 0; // Initialize index for buffer content.
	while ((current->content)[i]) // Iterate through buffer content until end.
	{
		i++; // Move to the next character.
		if ((current->content)[i - 1] == '\n') // If newline is found.
			break; // Exit the loop.
	}
	j = 0; // Initialize index for copying content.
	while ((current->content)[i]) // Iterate through remaining buffer content.
		(current->content)[j++] = (current->content)[i++]; // Copy content to the beginning of buffer.
	while (j <= BUFFER_SIZE) // Fill remaining buffer content with null characters.
		(current->content)[j++] = '\0'; // Null-terminate the buffer.
}

// Function to read a line from a file descriptor.
char *get_next_line(int fd)
{
	static t_fdList *fd_list; // Static variable to maintain file descriptor list between function calls.
	t_fdList *c_fd; // Pointer to file descriptor node for the current file descriptor.
	t_bufferList *begin; // Pointer to the beginning of buffer list.
	char *line; // Pointer to the string containing the read line.

	if (fd < 0 || BUFFER_SIZE < 1) // If invalid file descriptor or buffer size.
		return (NULL); // Return NULL.
	c_fd = find_fdbegin(fd, &fd_list); // Find or create file descriptor node.
	if (!c_fd) // If file descriptor node creation failed.
		return (NULL); // Return NULL.
	begin = c_fd->begin; // Get the beginning of buffer list for the file descriptor.
	if (read_file(fd, begin, begin)) // Read data from file descriptor and check if a complete line is available.
		line = join_buffers(begin); // Concatenate buffer contents into a single string.
	else
		line = NULL; // If no complete line is available, set line to NULL.
	clean_buffers(begin, c_fd); // Clean up buffer nodes after reading data.
	fd_list = clean_fd_list(fd_list, c_fd); // Clean up file descriptor list.
	return (line); // Return the read line.
}
