/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:27:12 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:27:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H // Header guard to prevent multiple inclusion of the header file.
# define LIBFT_H // Define the header file if not defined already.

# include "ft_printf.h" // Including the header file for custom printf function.
# include "get_next_line.h" // Including the header file for custom get_next_line function.

# include <string.h> // Including the header file for string manipulation functions.
# include <stdlib.h> // Including the header file for standard library functions.
# include <unistd.h> // Including the header file for standard I/O functions.
# include <sys/types.h> // Including the header file for system data types.
# include <sys/stat.h> // Including the header file for file status functions.
# include <fcntl.h> // Including the header file for file control functions.
# include <stdint.h> // Including the header file for integer types.

/* Declaration of libc functions */
void	*ft_memset(void *b, int c, size_t len); // Function to fill memory with a constant byte.
void	ft_bzero(void *s, size_t n); // Function to zero out bytes in a memory block.
void	*ft_memcpy(void *dst, const void *src, size_t n); // Function to copy memory area.
void	*ft_memccpy(void *d, const void *s, int c, size_t n); // Function to copy memory area until a character is found.
void	*ft_memmove(void *dst, const void *src, size_t len); // Function to copy memory area, handling overlap.
void	*ft_memchr(const void *s, int c, size_t n); // Function to locate a character in a memory block.
int		ft_memcmp(const void *s1, const void *s2, size_t n); // Function to compare memory areas.
size_t	ft_strlen(const char *s); // Function to calculate the length of a string.
int		ft_isalpha(int c); // Function to check if a character is alphabetic.
int		ft_isdigit(int c); // Function to check if a character is a digit.
int		ft_isalnum(int c); // Function to check if a character is alphanumeric.
int		ft_isascii(int c); // Function to check if a character is ASCII.
int		ft_isprint(int c); // Function to check if a character is printable.
int		ft_toupper(int c); // Function to convert a character to uppercase.
int		ft_tolower(int c); // Function to convert a character to lowercase.
char	*ft_strchr(const char *s, int c); // Function to locate a character in a string.
char	*ft_strrchr(const char *s, int c); // Function to locate a character in a string from the end.
int		ft_strncmp(const char *s1, const char *s2, size_t n); // Function to compare strings.
size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize); // Function to copy strings with size limit.
size_t	ft_strlcat(char *d, const char *s, size_t dstsize); // Function to concatenate strings with size limit.
char	*ft_strnstr(const char *haystack, const char *needle, size_t len); // Function to locate a substring.
int		ft_atoi(const char *str); // Function to convert a string to an integer.
void	*ft_calloc(size_t count, size_t size); // Function to allocate and zero-initialize memory.
char	*ft_strdup(const char *s1); // Function to duplicate a string.

/* Additional functions */
char	*ft_substr(char const *s, unsigned int start, size_t len); // Function to extract a substring from a string.
char	*ft_strjoin(char const *s1, char const *s2); // Function to concatenate two strings.
char	*ft_strtrim(char const *s1, char const *set); // Function to trim leading and trailing characters from a string.
char	**ft_split(char const *s, char c); // Function to split a string into substrings.
char	*ft_itoa(int n); // Function to convert an integer to a string.
char	*ft_strmapi(char const *s, char (*f)(unsigned int, char)); // Function to apply a function to each character of a string.
void	ft_putchar_fd(char c, int fd); // Function to write a character to a file descriptor.
void	ft_putstr_fd(char const *s, int fd); // Function to write a string to a file descriptor.
void	ft_putendl_fd(char const *s, int fd); // Function to write a string followed by a newline to a file descriptor.
void	ft_putnbr_fd(int n, int fd); // Function to write an integer to a file descriptor.
void	ft_striteri(char *s, void (*f)(unsigned int, char *)); // Function to apply a function to each character of a string with its index.

/* Bonus functions */
typedef struct s_list // Definition of a structure for a linked list node.
{
	void			*content; // Pointer to the content of the node.
	struct s_list	*next; // Pointer to the next node.
}					t_list; // Typedefining the structure as t_list.

t_list	*ft_lstnew(void *content); // Function to create a new linked list node.
void	ft_lstadd_front(t_list **alst, t_list *new); // Function to add a node to the beginning of a linked list.
int		ft_lstsize(t_list *lst); // Function to get the size of a linked list.
t_list	*ft_lstlast(t_list *lst); // Function to get the last node of a linked list.
void	ft_lstadd_back(t_list **alst, t_list *new); // Function to add a node to the end of a linked list.
void	ft_lstdelone(t_list *lst, void (*del)(void *)); // Function to delete a node from a linked list.
void	ft_lstclear(t_list **lst, void (*del)(void *)); // Function to delete all nodes from a linked list.
void	ft_lstiter(t_list *lst, void (*f)(void *)); // Function to apply a function to each node of a linked list.
t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *)); // Function to create a new linked list resulting from the application of a function to each node of the original list.

void	ft_swap(long *a, long *b); // Function to swap two integers.
int		ft_strcmp(const char *s1, const char *s2); // Function to compare strings.
char	*ft_strrjoin(char const *s1, char const *s2, char const *s3); // Function to concatenate three strings.
void	free_tabstr(char **tab); // Function to free memory allocated to an array of strings.
size_t	ft_countc(const char *str, char c); // Function to count occurrences of a character in a string.

#endif // End of header guard.
