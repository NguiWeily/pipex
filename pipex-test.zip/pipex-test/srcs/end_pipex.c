/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   end_pipex.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:28:28 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:28:31 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

// Function to clean up resources at the end of pipex execution
void	end_pipex(int fd[2], char **path)
{
    // Close the input file descriptor if it is open
	if (fd && fd[0] > 0)
		close(fd[0]);
    
    // Close the output file descriptor if it is open
	if (fd && fd[1] > 0)
		close(fd[1]);
    
    // Free the memory allocated for the path array
	free_tabstr(path);
}
