/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/14 17:30:01 by wngui             #+#    #+#             */
/*   Updated: 2024/01/14 17:30:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

static char	*get_path_ptr(char *envp[])
{
	int		i;
	char	*ptr;

	i = 0;
	while (1)
	{
		ptr = envp[i];
		if (!ptr)
			break ;
		if (strncmp(ptr, "PATH=", 5) == 0)
			return (ptr);
		i++;
	}
	return (NULL);
}

char	**get_path(char *envp[])
{
	char	*path_ptr;
	char	**path;

	path_ptr = get_path_ptr(envp);
	path_ptr += 5;
	path = ft_split(path_ptr, ':');
	return (path);
}
